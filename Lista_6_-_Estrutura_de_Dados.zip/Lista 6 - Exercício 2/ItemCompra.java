class ItemCompra {
    private String nome;
    
    public ItemCompra(String nome) {
        this.nome = nome;
    }
    
    public String getNome() {
        return nome;
    }
}